﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


    public  class frmMain : Form
    {
        const double FIVEDIVIDEDBYNINE = .555555555555555d;
        const double NINEDIVIDEDBYFIVE = 1.80d;


        private Button btnToFahrenheit;
        private TextBox txtTempToConvert;
        private Label label2;
        private Label lblAnswer;
        private Button btnToCelsius;
        private Button btnExit;
        private Label label1;
        #region Windows code
        private void InitializeComponent()
        {
            this.btnToFahrenheit = new System.Windows.Forms.Button();
            this.txtTempToConvert = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.btnToCelsius = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnToFahrenheit
            // 
            this.btnToFahrenheit.Location = new System.Drawing.Point(162, 86);
            this.btnToFahrenheit.Name = "btnToFahrenheit";
            this.btnToFahrenheit.Size = new System.Drawing.Size(144, 23);
            this.btnToFahrenheit.TabIndex = 17;
            this.btnToFahrenheit.Text = "Convert to Fahrenheit";
            this.btnToFahrenheit.UseVisualStyleBackColor = true;
            this.btnToFahrenheit.Click += new System.EventHandler(this.btnToFahrenheit_Click);
            // 
            // txtTempToConvert
            // 
            this.txtTempToConvert.Location = new System.Drawing.Point(118, 44);
            this.txtTempToConvert.Name = "txtTempToConvert";
            this.txtTempToConvert.Size = new System.Drawing.Size(100, 20);
            this.txtTempToConvert.TabIndex = 15;
            this.txtTempToConvert.Enter += new System.EventHandler(this.txtTempToConvert_Enter);
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(12, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Enter temperature:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAnswer
            // 
            this.lblAnswer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAnswer.Location = new System.Drawing.Point(224, 43);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(203, 20);
            this.lblAnswer.TabIndex = 19;
            this.lblAnswer.Text = "Equals ";
            this.lblAnswer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAnswer.Visible = false;
            // 
            // btnToCelsius
            // 
            this.btnToCelsius.Location = new System.Drawing.Point(12, 86);
            this.btnToCelsius.Name = "btnToCelsius";
            this.btnToCelsius.Size = new System.Drawing.Size(144, 23);
            this.btnToCelsius.TabIndex = 20;
            this.btnToCelsius.Text = "Convert to Celsius";
            this.btnToCelsius.UseVisualStyleBackColor = true;
            this.btnToCelsius.Click += new System.EventHandler(this.btnToCelsius_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(352, 86);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 21;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmMain
            // 
            this.ClientSize = new System.Drawing.Size(448, 151);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnToCelsius);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnToFahrenheit);
            this.Controls.Add(this.txtTempToConvert);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Temperature Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        public frmMain()
        {
            InitializeComponent();
        }

        public static void Main()
        {
            frmMain main = new frmMain();
            Application.Run(main);
        }


        private void btnToFahrenheit_Click(object sender, EventArgs e)
        {
            bool flag;
            double temp;

            flag = double.TryParse(txtTempToConvert.Text, out temp);
            if (flag == false)
            {
                MessageBox.Show("Numeric only. Re-enter.");
                txtTempToConvert.Focus();
                return;
            }
            temp = NINEDIVIDEDBYFIVE * temp + 32.0;
            lblAnswer.Text = "equals " + temp.ToString() + " Fahrenheit";
            lblAnswer.Visible = true;

        }

        private void txtTempToConvert_Enter(object sender, EventArgs e)
        {
            lblAnswer.Visible = false;  // Anytime they want to enter a new number
                                        // hide the old answer.

        }

        private void btnToCelsius_Click(object sender, EventArgs e)
        {
            bool flag;
            double temp;

            flag = double.TryParse(txtTempToConvert.Text, out temp);
            if (flag == false)
            {
                MessageBox.Show("Numeric only. Re-enter.");
                txtTempToConvert.Focus();
                return;
            }
            temp = FIVEDIVIDEDBYNINE * (temp - 32.0);
            lblAnswer.Text = "equals " + temp.ToString() + " Celsius";
            lblAnswer.Visible = true;

        }

 
        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }


    }

