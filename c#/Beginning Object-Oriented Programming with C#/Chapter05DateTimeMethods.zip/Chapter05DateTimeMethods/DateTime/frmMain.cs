﻿using System;
using System.Windows.Forms;

public class frmMain : Form
{
  private Label label1;
  private TextBox txtFull;
  private TextBox txtLong;
  private Label label2;
  private TextBox txtShort;
  private Label label3;
  private TextBox txtGeneral;
  private Label label4;
  private TextBox txtLongTime;
  private Label label5;
  private TextBox txtShortTime;
  private Label label6;
  private TextBox txtNewYears;
  private Label label7;
  private Button btnRefresh;
  private Button btnClose;
  #region Windows Code
  private void InitializeComponent()
  {
    this.label1 = new System.Windows.Forms.Label();
    this.txtFull = new System.Windows.Forms.TextBox();
    this.txtLong = new System.Windows.Forms.TextBox();
    this.label2 = new System.Windows.Forms.Label();
    this.txtShort = new System.Windows.Forms.TextBox();
    this.label3 = new System.Windows.Forms.Label();
    this.txtGeneral = new System.Windows.Forms.TextBox();
    this.label4 = new System.Windows.Forms.Label();
    this.txtLongTime = new System.Windows.Forms.TextBox();
    this.label5 = new System.Windows.Forms.Label();
    this.txtShortTime = new System.Windows.Forms.TextBox();
    this.label6 = new System.Windows.Forms.Label();
    this.txtNewYears = new System.Windows.Forms.TextBox();
    this.label7 = new System.Windows.Forms.Label();
    this.btnRefresh = new System.Windows.Forms.Button();
    this.btnClose = new System.Windows.Forms.Button();
    this.SuspendLayout();
    // 
    // label1
    // 
    this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.label1.Location = new System.Drawing.Point(12, 30);
    this.label1.Name = "label1";
    this.label1.Size = new System.Drawing.Size(222, 20);
    this.label1.TabIndex = 0;
    this.label1.Text = "Full Date and Time:";
    this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
    // 
    // txtFull
    // 
    this.txtFull.Location = new System.Drawing.Point(240, 30);
    this.txtFull.Name = "txtFull";
    this.txtFull.Size = new System.Drawing.Size(239, 20);
    this.txtFull.TabIndex = 1;
    // 
    // txtLong
    // 
    this.txtLong.Location = new System.Drawing.Point(240, 59);
    this.txtLong.Name = "txtLong";
    this.txtLong.Size = new System.Drawing.Size(239, 20);
    this.txtLong.TabIndex = 3;
    // 
    // label2
    // 
    this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.label2.Location = new System.Drawing.Point(12, 59);
    this.label2.Name = "label2";
    this.label2.Size = new System.Drawing.Size(222, 20);
    this.label2.TabIndex = 2;
    this.label2.Text = "Long Date:";
    this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
    // 
    // txtShort
    // 
    this.txtShort.Location = new System.Drawing.Point(240, 85);
    this.txtShort.Name = "txtShort";
    this.txtShort.Size = new System.Drawing.Size(239, 20);
    this.txtShort.TabIndex = 5;
    // 
    // label3
    // 
    this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.label3.Location = new System.Drawing.Point(12, 85);
    this.label3.Name = "label3";
    this.label3.Size = new System.Drawing.Size(222, 20);
    this.label3.TabIndex = 4;
    this.label3.Text = "Short Date:";
    this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
    // 
    // txtGeneral
    // 
    this.txtGeneral.Location = new System.Drawing.Point(240, 111);
    this.txtGeneral.Name = "txtGeneral";
    this.txtGeneral.Size = new System.Drawing.Size(239, 20);
    this.txtGeneral.TabIndex = 7;
    // 
    // label4
    // 
    this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.label4.Location = new System.Drawing.Point(12, 111);
    this.label4.Name = "label4";
    this.label4.Size = new System.Drawing.Size(222, 20);
    this.label4.TabIndex = 6;
    this.label4.Text = "General Date and TIme:";
    this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
    // 
    // txtLongTime
    // 
    this.txtLongTime.Location = new System.Drawing.Point(240, 137);
    this.txtLongTime.Name = "txtLongTime";
    this.txtLongTime.Size = new System.Drawing.Size(239, 20);
    this.txtLongTime.TabIndex = 9;
    // 
    // label5
    // 
    this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.label5.Location = new System.Drawing.Point(12, 137);
    this.label5.Name = "label5";
    this.label5.Size = new System.Drawing.Size(222, 20);
    this.label5.TabIndex = 8;
    this.label5.Text = "Long Time:";
    this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
    // 
    // txtShortTime
    // 
    this.txtShortTime.Location = new System.Drawing.Point(240, 163);
    this.txtShortTime.Name = "txtShortTime";
    this.txtShortTime.Size = new System.Drawing.Size(239, 20);
    this.txtShortTime.TabIndex = 11;
    // 
    // label6
    // 
    this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.label6.Location = new System.Drawing.Point(12, 163);
    this.label6.Name = "label6";
    this.label6.Size = new System.Drawing.Size(222, 20);
    this.label6.TabIndex = 10;
    this.label6.Text = "Short Time:";
    this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
    // 
    // txtNewYears
    // 
    this.txtNewYears.Location = new System.Drawing.Point(240, 189);
    this.txtNewYears.Name = "txtNewYears";
    this.txtNewYears.Size = new System.Drawing.Size(239, 20);
    this.txtNewYears.TabIndex = 13;
    // 
    // label7
    // 
    this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.label7.Location = new System.Drawing.Point(12, 189);
    this.label7.Name = "label7";
    this.label7.Size = new System.Drawing.Size(222, 20);
    this.label7.TabIndex = 12;
    this.label7.Text = "Days Until New Years:";
    this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
    // 
    // btnRefresh
    // 
    this.btnRefresh.Location = new System.Drawing.Point(12, 242);
    this.btnRefresh.Name = "btnRefresh";
    this.btnRefresh.Size = new System.Drawing.Size(75, 23);
    this.btnRefresh.TabIndex = 14;
    this.btnRefresh.Text = "&Refresh";
    this.btnRefresh.UseVisualStyleBackColor = true;
    this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
    // 
    // btnClose
    // 
    this.btnClose.Location = new System.Drawing.Point(404, 242);
    this.btnClose.Name = "btnClose";
    this.btnClose.Size = new System.Drawing.Size(75, 23);
    this.btnClose.TabIndex = 15;
    this.btnClose.Text = "&Close";
    this.btnClose.UseVisualStyleBackColor = true;
    this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
    // 
    // frmMain
    // 
    this.ClientSize = new System.Drawing.Size(506, 280);
    this.Controls.Add(this.btnClose);
    this.Controls.Add(this.btnRefresh);
    this.Controls.Add(this.txtNewYears);
    this.Controls.Add(this.label7);
    this.Controls.Add(this.txtShortTime);
    this.Controls.Add(this.label6);
    this.Controls.Add(this.txtLongTime);
    this.Controls.Add(this.label5);
    this.Controls.Add(this.txtGeneral);
    this.Controls.Add(this.label4);
    this.Controls.Add(this.txtShort);
    this.Controls.Add(this.label3);
    this.Controls.Add(this.txtLong);
    this.Controls.Add(this.label2);
    this.Controls.Add(this.txtFull);
    this.Controls.Add(this.label1);
    this.Name = "frmMain";
    this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
    this.Text = "Date Time Tester";
    this.ResumeLayout(false);
    this.PerformLayout();

  }
  #endregion


  public frmMain()
  {
    InitializeComponent();
    UpdateTimeInfo();       // Update textboxes

  }


  [STAThread]
  public static void Main()
  {
    frmMain main = new frmMain();
    Application.Run(main);
  }

  private void UpdateTimeInfo()
    {
        int days;
        DateTime myTime = new DateTime();
        myTime = DateTime.Now;

        DateTime newYears = new DateTime(myTime.Year, 12, 31);
             
        txtFull.Text = myTime.ToString("f");
        txtLong.Text = myTime.ToString("D");
        txtShort.Text = myTime.ToString("d");
        txtGeneral.Text = myTime.ToString("g");
        txtLongTime.Text = myTime.ToString("T");
        txtShortTime.Text = myTime.ToString("t");
             
        days = newYears.DayOfYear - myTime.DayOfYear;
        txtNewYears.Text = days.ToString();
    }

  private void btnRefresh_Click(object sender, EventArgs e)
  {
      bool flag;
      int month;
      int day;
      int year;

    UpdateTimeInfo();
    string temp = "05/03/1943";
    flag = int.TryParse(temp.Substring(0, 2), out month);
    flag = int.TryParse(temp.Substring(3, 2), out day);
    flag = int.TryParse(temp.Substring(6, 4), out year);
    DateTime birthdate = new DateTime(year, month, day);

    DateTime currentDate = DateTime.Now;

      // get the difference in years
    int years = DateTime.Now.Year - birthdate.Year; 
    // subtract another year if we're before the
    // birth day in the current year
    if (DateTime.Now.Month < birthdate.Month || 
            (DateTime.Now.Month == birthdate.Month && 
             DateTime.Now.Day < birthdate.Day)) 
        years--;
    }

  private void btnClose_Click(object sender, EventArgs e)
  {
    Close();
  }
}