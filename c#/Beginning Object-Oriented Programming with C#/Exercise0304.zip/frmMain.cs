﻿using System;
using System.Windows.Forms;

public class frmMain : Form
{
    const double SPEEDOFLIGHT = 186000d;

    private TextBox txtMiles;
    private Button btnCalc;
    private Button btnExit;
    private Label lblAnswer;
    private Label label1;
    #region Windows Code
    private void InitializeComponent()
    {
            this.label1 = new System.Windows.Forms.Label();
            this.txtMiles = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Distance in miles:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtMiles
            // 
            this.txtMiles.Location = new System.Drawing.Point(118, 29);
            this.txtMiles.Name = "txtMiles";
            this.txtMiles.Size = new System.Drawing.Size(100, 20);
            this.txtMiles.TabIndex = 1;
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(19, 95);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(75, 23);
            this.btnCalc.TabIndex = 2;
            this.btnCalc.Text = "&Calculate";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(143, 95);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblAnswer
            // 
            this.lblAnswer.Location = new System.Drawing.Point(12, 59);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(206, 20);
            this.lblAnswer.TabIndex = 4;
            this.lblAnswer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmMain
            // 
            this.ClientSize = new System.Drawing.Size(234, 155);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.txtMiles);
            this.Controls.Add(this.label1);
            this.Name = "frmMain";
            this.Text = "Find time to object";
            this.ResumeLayout(false);
            this.PerformLayout();

    }
    #endregion


    public frmMain()
    {
        InitializeComponent();
    }


    [STAThread]
    public static void Main()
    {
        frmMain main = new frmMain();
        Application.Run(main);
    }

    private void btnCalc_Click(object sender, EventArgs e)
    {
        bool flag;
        double time;
        double distance;

        flag = double.TryParse(txtMiles.Text, out distance);    // Make it a double
        if (flag == false)
        {
            MessageBox.Show("Input error. Re-enter.");
            txtMiles.Focus();
            return;
        }
        time = distance / SPEEDOFLIGHT;             // Speed per second
        if (time / 60.0 > 1.0)                        // Can we use minutes??
        {
            lblAnswer.Text = "It takes " + (time / 60.0).ToString() + " minutes";   // Yep...
        }
        else
        {
            lblAnswer.Text = "It takes " + time.ToString() + " seconds";            // Nope...
        }
    }

    private void btnExit_Click(object sender, EventArgs e)
    {
        Close();
    }
}
