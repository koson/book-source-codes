using System;
using System.Windows.Forms;

public class frmMain : Form
{
    private Label label2;
    private Label label3;
    private TextBox txtMonth;
    private TextBox txtDay;
    private TextBox txtYear;
    private TextBox txtBirthday;
    private Button btnCalc;
    private Button btnExit;
    private Label label1;
    #region Windows code
    private void InitializeComponent()
    {
        this.label1 = new System.Windows.Forms.Label();
        this.label2 = new System.Windows.Forms.Label();
        this.label3 = new System.Windows.Forms.Label();
        this.txtMonth = new System.Windows.Forms.TextBox();
        this.txtDay = new System.Windows.Forms.TextBox();
        this.txtYear = new System.Windows.Forms.TextBox();
        this.txtBirthday = new System.Windows.Forms.TextBox();
        this.btnCalc = new System.Windows.Forms.Button();
        this.btnExit = new System.Windows.Forms.Button();
        this.SuspendLayout();
        // 
        // label1
        // 
        this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.label1.Location = new System.Drawing.Point(21, 25);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(100, 20);
        this.label1.TabIndex = 0;
        this.label1.Text = "Month:";
        this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // label2
        // 
        this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.label2.Location = new System.Drawing.Point(21, 45);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(100, 20);
        this.label2.TabIndex = 1;
        this.label2.Text = "Day:";
        this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // label3
        // 
        this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.label3.Location = new System.Drawing.Point(21, 65);
        this.label3.Name = "label3";
        this.label3.Size = new System.Drawing.Size(100, 20);
        this.label3.TabIndex = 2;
        this.label3.Text = "Year:";
        this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // txtMonth
        // 
        this.txtMonth.Location = new System.Drawing.Point(122, 25);
        this.txtMonth.Name = "txtMonth";
        this.txtMonth.Size = new System.Drawing.Size(128, 20);
        this.txtMonth.TabIndex = 3;
        this.txtMonth.Text = "5";
        // 
        // txtDay
        // 
        this.txtDay.Location = new System.Drawing.Point(122, 45);
        this.txtDay.Name = "txtDay";
        this.txtDay.Size = new System.Drawing.Size(128, 20);
        this.txtDay.TabIndex = 4;
        this.txtDay.Text = "10";
        // 
        // txtYear
        // 
        this.txtYear.Location = new System.Drawing.Point(122, 65);
        this.txtYear.Name = "txtYear";
        this.txtYear.Size = new System.Drawing.Size(128, 20);
        this.txtYear.TabIndex = 5;
        this.txtYear.Text = "1950";
        // 
        // txtBirthday
        // 
        this.txtBirthday.Location = new System.Drawing.Point(21, 100);
        this.txtBirthday.Name = "txtBirthday";
        this.txtBirthday.ReadOnly = true;
        this.txtBirthday.Size = new System.Drawing.Size(229, 20);
        this.txtBirthday.TabIndex = 6;
        this.txtBirthday.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        this.txtBirthday.Visible = false;
        // 
        // btnCalc
        // 
        this.btnCalc.Location = new System.Drawing.Point(21, 145);
        this.btnCalc.Name = "btnCalc";
        this.btnCalc.Size = new System.Drawing.Size(75, 23);
        this.btnCalc.TabIndex = 7;
        this.btnCalc.Text = "Calculate";
        this.btnCalc.UseVisualStyleBackColor = true;
        this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
        // 
        // btnExit
        // 
        this.btnExit.Location = new System.Drawing.Point(175, 145);
        this.btnExit.Name = "btnExit";
        this.btnExit.Size = new System.Drawing.Size(75, 23);
        this.btnExit.TabIndex = 8;
        this.btnExit.Text = "E&xit";
        this.btnExit.UseVisualStyleBackColor = true;
        this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
        // 
        // frmMain
        // 
        this.ClientSize = new System.Drawing.Size(268, 189);
        this.Controls.Add(this.btnExit);
        this.Controls.Add(this.btnCalc);
        this.Controls.Add(this.txtBirthday);
        this.Controls.Add(this.txtYear);
        this.Controls.Add(this.txtDay);
        this.Controls.Add(this.txtMonth);
        this.Controls.Add(this.label3);
        this.Controls.Add(this.label2);
        this.Controls.Add(this.label1);
        this.Name = "frmMain";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Birthday Calculator";
        this.ResumeLayout(false);
        this.PerformLayout();

    }
    #endregion

    public frmMain()
    {
        InitializeComponent();
    }

    public static void Main()
    {
        frmMain main = new frmMain();
        Application.Run(main);
    }

    private void btnCalc_Click(object sender, EventArgs e)
    {
        bool flag;
        int month;
        int day;
        int year;
        DateTime myBirthday;

        flag = true;
        //                         Input Step
        flag = int.TryParse(txtMonth.Text, out month);
        if (flag == false)
        {
            MessageBox.Show("Enter number for month (Jan = 1):");
            txtMonth.Focus();
            return;
        }

        flag = int.TryParse(txtDay.Text, out day);
        if (flag == false)
        {
            MessageBox.Show("Enter number for day (1-31):");
            txtDay.Focus();
            return;
        }
        flag = int.TryParse(txtYear.Text, out year);
        if (flag == false)
        {
            MessageBox.Show("Enter number for year (yyyy):");
            txtMonth.Focus();
            return;
        }

        //                         Process Step
        myBirthday = new DateTime(year, month, day);
        txtBirthday.Text = "You were born: " + myBirthday.ToString("D");
        txtBirthday.Visible = true;
    }

    private void btnExit_Click(object sender, EventArgs e)
    {
        Close();
    }
}