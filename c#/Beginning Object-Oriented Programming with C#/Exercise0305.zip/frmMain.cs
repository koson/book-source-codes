﻿using System;
using System.Windows.Forms;

public class frmMain : Form
{
    const decimal SALESTAXRATE = .06M;
    const decimal SHIPPINGPERYARD = .05M;

    private Label label2;
    private Label lblShipping;
    private Label label4;
    private Label label5;
    private TextBox txtPrice;
    private TextBox txtYards;
    private TextBox txtShipping;
    private TextBox txtTax;
    private TextBox txtTotal;
    private Button btnCost;
    private Button btnExit;
    private Label label1;
    #region Windows Code
    private void InitializeComponent()
    {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblShipping = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtYards = new System.Windows.Forms.TextBox();
            this.txtShipping = new System.Windows.Forms.TextBox();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.btnCost = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Price per yard:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(12, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Yards ordered:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblShipping
            // 
            this.lblShipping.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShipping.Location = new System.Drawing.Point(12, 61);
            this.lblShipping.Name = "lblShipping";
            this.lblShipping.Size = new System.Drawing.Size(100, 20);
            this.lblShipping.TabIndex = 2;
            this.lblShipping.Text = "Shipping per yard:";
            this.lblShipping.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(12, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Sales tax:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Location = new System.Drawing.Point(12, 101);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Total cost:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(109, 21);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(100, 20);
            this.txtPrice.TabIndex = 5;
            this.txtPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtYards
            // 
            this.txtYards.Location = new System.Drawing.Point(109, 42);
            this.txtYards.Name = "txtYards";
            this.txtYards.Size = new System.Drawing.Size(100, 20);
            this.txtYards.TabIndex = 6;
            this.txtYards.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtYards.Leave += new System.EventHandler(this.txtYards_Leave);
            // 
            // txtShipping
            // 
            this.txtShipping.Location = new System.Drawing.Point(109, 62);
            this.txtShipping.Name = "txtShipping";
            this.txtShipping.Size = new System.Drawing.Size(100, 20);
            this.txtShipping.TabIndex = 7;
            this.txtShipping.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTax
            // 
            this.txtTax.Location = new System.Drawing.Point(109, 81);
            this.txtTax.Name = "txtTax";
            this.txtTax.Size = new System.Drawing.Size(100, 20);
            this.txtTax.TabIndex = 8;
            this.txtTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(109, 101);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(100, 20);
            this.txtTotal.TabIndex = 9;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnCost
            // 
            this.btnCost.Location = new System.Drawing.Point(12, 153);
            this.btnCost.Name = "btnCost";
            this.btnCost.Size = new System.Drawing.Size(75, 23);
            this.btnCost.TabIndex = 10;
            this.btnCost.Text = "&Clear";
            this.btnCost.UseVisualStyleBackColor = true;
            this.btnCost.Click += new System.EventHandler(this.btnCost_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(134, 153);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmMain
            // 
            this.ClientSize = new System.Drawing.Size(232, 191);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCost);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtTax);
            this.Controls.Add(this.txtShipping);
            this.Controls.Add(this.txtYards);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblShipping);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cost of Order";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

    }
    #endregion


    public frmMain()
    {
        InitializeComponent();
        txtShipping.Text = SHIPPINGPERYARD.ToString();
    }


    [STAThread]
    public static void Main()
    {
        frmMain main = new frmMain();
        Application.Run(main);
    }

    private void frmMain_Load(object sender, EventArgs e)
    {

    }

    private void btnCost_Click(object sender, EventArgs e)
    {
        txtPrice.Text = "";
        txtYards.Text = "";
        txtShipping.Text = SHIPPINGPERYARD.ToString();
        txtTax.Text = "";
        txtTotal.Text = "";


    }

    private void txtYards_Leave(object sender, EventArgs e)
    {
        bool flag;
        decimal temp;
        decimal price;
        decimal yards;
        decimal shipping;
        decimal tax;
        decimal total;

        flag = decimal.TryParse(txtPrice.Text, out price);
        if (flag == false)
        {
            MessageBox.Show("Numeric only. Re-enter");
            txtPrice.Focus();
            return;
        }
        txtPrice.Text = price.ToString("C");
        flag = decimal.TryParse(txtYards.Text, out yards);
        if (flag == false)
        {
            MessageBox.Show("Numeric only. Re-enter");
            txtYards.Focus();
            return;
        }
        lblShipping.Text = "Total shipping:";
        shipping = yards * SHIPPINGPERYARD;
        total = price * yards;
        tax = total * SALESTAXRATE;
        txtShipping.Text = shipping.ToString("C");
        txtTax.Text = tax.ToString("C");
        total = total + tax + shipping;
        txtTotal.Text = total.ToString("C");
    }

    private void btnExit_Click(object sender, EventArgs e)
    {
        Close();

    }
}
